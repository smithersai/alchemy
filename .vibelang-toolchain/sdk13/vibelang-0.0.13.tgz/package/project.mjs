import { loaderScope } from "./loader-scope.mjs"
import { diagnosticsForFile } from "./diagnostics.mjs"
import { isVibeLangFile } from "./source.mjs"
// Whole-project compilation for the bundler plugins (vibelang-vite,
// vibelang-unplugin) and the Node and Bun loaders (vibelang/register,
// vibelang/bun).
//
// VibeLang's emit is type-directed: a module's JavaScript depends on the
// contracts of the modules it imports, so no module compiles alone. Each
// compile is one vibelang process over a whole tsconfig project, and its
// result is kept in a persistent cache (cache.mjs) that later processes reuse
// while the project's inputs are unchanged.
import { spawn, spawnSync } from "node:child_process"
import { closeSync, existsSync, mkdtempSync, openSync, readdirSync, readFileSync, readSync, realpathSync, rmSync, statSync } from "node:fs"
import { createRequire } from "node:module"
import { temporaryRoot } from "./temporary.mjs"
import { performance } from "node:perf_hooks"
import { basename, dirname, isAbsolute, join, parse, relative, resolve } from "node:path"
import { launcherBinary, loaderRecord, loaderRecordFile, parseJsonc, projectCache } from "./cache.mjs"

const slash = (path) => path.replaceAll("\\", "/")
const located = /^(.+?)\((\d+),(\d+)\):\s+(error|warning)\s+(\w+\d+):\s?(.*)$/
const global = /^(error|warning)\s+(\w+\d+):\s?(.*)$/

/**
 * Returns the compiler command: the `compiler` option, else VIBELANG_BINARY,
 * else the launcher of the vibelang package installed for `root`.
 */
export function findCompiler(root, compiler) {
  if (compiler) return resolve(root, compiler)
  if (process.env.VIBELANG_BINARY) return resolve(root, process.env.VIBELANG_BINARY)
  const require = createRequire(join(resolve(root), "package.json"))
  return join(dirname(require.resolve("vibelang/package.json")), "bin/vibelang")
}

// The npm launcher and the native platform packages both install bin/vibelang,
// so read the shebang instead of trusting the filename.
function isNodeLauncher(path) {
  if (/\.(?:[cm]?js)$/.test(path)) return true
  let file
  try {
    file = openSync(path, "r")
    const header = Buffer.alloc(256)
    const bytes = readSync(file, header, 0, header.length, 0)
    return /^#![^\r\n]*\bnode(?:\s|$)/.test(header.subarray(0, bytes).toString("utf8"))
  } catch {
    return false
  } finally {
    if (file !== undefined) closeSync(file)
  }
}

// The vibelang launcher only finds the native compiler and runs it, so a
// compile runs that binary itself and skips starting Node for the launcher.
function command(compiler, args) {
  const binary = launcherBinary(compiler)
  if (binary !== undefined && existsSync(binary)) return [binary, args]
  return isNodeLauncher(compiler) ? [process.execPath, [compiler, ...args]] : [compiler, args]
}

/**
 * Parses `vibelang --pretty false --listFiles` output into the files the
 * program read and the diagnostics it reported. A diagnostic's position is
 * 1-based, as the compiler prints it.
 */
export function parseOutput(output, root) {
  const files = []
  const diagnostics = []
  let diagnostic
  const lines = output.split(/\r?\n/)
  const library = /^bundled:\/\/\/libs\/lib\.[^/\s]+\.d\.ts$/
  const libraryListings = new Set()
  let listing = true
  // A library block ends at a filesystem listing or the end of the output.
  // Source excerpts can quote the same URLs before continuing their message.
  for (let index = lines.length - 1; index >= 0; index--) {
    const line = lines[index]
    if (!line) continue
    if (library.test(line)) {
      if (listing) libraryListings.add(index)
    } else {
      listing = isAbsolute(line.trim())
    }
  }
  for (const [index, line] of lines.entries()) {
    let match
    if ((match = line.match(located))) {
      diagnostic = {
        file: resolve(root, match[1]), line: Number(match[2]), column: Number(match[3]),
        category: match[4], code: match[5], text: match[6]
      }
      diagnostics.push(diagnostic)
    } else if ((match = line.match(global))) {
      diagnostic = { category: match[1], code: match[2], text: match[3] }
      diagnostics.push(diagnostic)
    } else if (/^\s/.test(line)) {
      if (diagnostic) diagnostic.text += "\n" + line
    } else if (libraryListings.has(index)) {
      // Embedded standard libraries belong to the compiler's file listing.
      // They have no filesystem path to watch or fingerprint.
      diagnostic = undefined
    } else if (isAbsolute(line.trim()) &&
      // A multiline message can quote source comments at column zero.
      // Keep existing input paths even when their spelling resembles a
      // comment. Once file listing starts, missing paths remain inputs too.
      !(diagnostic && /^\/[*/]/.test(line.trim()) && !existsSync(line.trim()))) {
      files.push(line.trim())
      diagnostic = undefined
    } else if (diagnostic && line) {
      diagnostic.text += "\n" + line
    }
  }
  return { files, diagnostics }
}

const imported = /^\s+Imported via (".*"|'.*') from file '(.+?)'(?: with packageId '[^']*')?( to import .+)?$/
const supplemental = /^\s+Supplemental virtual file produced by the content mapper for file '(.+)'\.$/
const rooted = /^\s+(?:Matched by (?:default )?include pattern|Part of 'files' list|Root file specified)/

/**
 * Parses `vibelang --pretty false --explainFiles --listFilesOnly` output into
 * the program's files, the ones its config lists (roots: an include pattern or
 * `files` names them, where the rest are only imported), the imports its sources
 * write, and the diagnostics the compiler reported. Each import is { importer, specifier, file }: the file
 * the compiler resolved `specifier` to. Imports the compiler adds itself, such
 * as JSX factories and import helpers, and its bundled libraries are left out.
 * A virtual file the compiler derives from a source, such as the body of a
 * .vibe file's module declaration (D283), is part of that source: it is not a
 * file, and its imports are the source's. The output's paths are relative to
 * root; the result's are absolute.
 */
export function parseExplainFiles(output, root) {
  const files = []
  const roots = []
  const imports = []
  const diagnostics = []
  const sources = new Map() // each virtual file, to the source it is part of
  // An indented line belongs to the last unindented one: a file's reasons or a diagnostic's detail.
  let file
  let diagnostic
  let match
  for (const line of output.split(/\r?\n/)) {
    if (/^\s/.test(line)) {
      if (diagnostic) diagnostic.text += "\n" + line
      else if (file && (match = line.match(imported)) && !match[3]) {
        imports.push({ importer: resolve(root, match[2]), specifier: match[1].slice(1, -1), file })
      } else if (file && (match = line.match(supplemental))) {
        sources.set(file, resolve(root, match[1]))
      } else if (file && rooted.test(line)) {
        roots.push(file)
      }
      continue
    }
    file = diagnostic = undefined
    if ((match = line.match(located))) {
      diagnostic = {
        file: resolve(root, match[1]), line: Number(match[2]), column: Number(match[3]),
        category: match[4], code: match[5], text: match[6]
      }
      diagnostics.push(diagnostic)
    } else if ((match = line.match(global))) {
      diagnostic = { category: match[1], code: match[2], text: match[3] }
      diagnostics.push(diagnostic)
    } else if (line.trim() && !line.startsWith("bundled:")) {
      file = resolve(root, line.trim())
      files.push(file)
    }
  }
  return {
    files: files.filter((file) => !sources.has(file)),
    roots: roots.filter((file) => !sources.has(file)),
    imports: imports.map((entry) => sources.has(entry.importer) ? { ...entry, importer: sources.get(entry.importer) } : entry),
    diagnostics
  }
}

/**
 * projectImports lists a tsconfig project's files and the imports its `.ts`
 * and `.vibe` sources write, each with the file the compiler resolved it to,
 * without type-checking the project. A tool that needs a module graph, such as
 * a circular-dependency check, reads it here instead of resolving `.vibe`
 * specifiers itself. It returns { files, imports, errors }; errors holds the
 * diagnostics that stopped the compiler from reading the project.
 */
export function projectImports(options) {
  const { files, imports, errors } = projectProgram(options)
  return { files, imports, errors }
}

// projectImports' listing, with the files the config lists as roots.
function projectProgram({ project, root, compiler }) {
  project = resolve(project)
  root = resolve(root ?? dirname(project))
  compiler ??= findCompiler(root)
  const [file, argv] = command(compiler, ["--project", project, "--pretty", "false", "--explainFiles", "--listFilesOnly"])
  const run = spawnSync(file, argv, { cwd: root, encoding: "utf8", maxBuffer: 1 << 30 })
  if (run.error) throw new Error(`vibelang: ${run.error.message}\nCompiler: ${compiler}`)
  const output = run.stdout + run.stderr
  const { files, roots, imports, diagnostics } = parseExplainFiles(output, root)
  const errors = diagnostics.filter((diagnostic) => diagnostic.category === "error")
  if (run.status !== 0 && !errors.length) {
    errors.push({ category: "error", code: "vibelang", text: output.trim() || `exited with ${run.signal || run.status}` })
  }
  return { files, roots, imports, errors }
}

/** Formats a diagnostic as `file:line:column - error TS2322: text`. */
export function formatDiagnostic(diagnostic) {
  const where = diagnostic.file ? `${diagnostic.file}:${diagnostic.line}:${diagnostic.column} - ` : ""
  return `${where}${diagnostic.category} ${diagnostic.code}: ${diagnostic.text}`
}

// Emit from the filesystem root because a project may include sources above
// its directory. Public project results check every input; loader compiles
// privately narrow checking and emission to their own Vibe sources.
const emitRoot = (root) => parse(resolve(root)).root

const emitArgs = (project, root, out, loader, extra = []) => [
  "--project", project, "--project-emit", ...(loader ? ["--loader-root", resolve(root)] : []),
  "--pretty", "false", "--listFiles", "true", "--rootDir", emitRoot(root),
  "--outDir", out, "--sourceMap", "true", "--inlineSources", "true",
  "--inlineSourceMap", "false", "--sourceRoot", slash(emitRoot(root)).replace(/\/?$/, "/"), "--declaration", "false", "--declarationMap", "false",
  "--noEmit", "false", "--emitDeclarationOnly", "false", "--noEmitOnError", "false",
  // A project checked with --noEmit may import .ts files without a rewrite of its
  // own; emitting it then needs one (TS5096), and the output imports .js anyway.
  "--rewriteRelativeImportExtensions", "true",
  // The loaders emit JavaScript alone, which a composite project refuses
  // (TS6304, TS6379); its references are not built here either.
  "--composite", "false", "--incremental", "false", ...extra
]

const realpath = (path) => {
  try {
    return realpathSync(path)
  } catch {
    return path
  }
}

/**
 * Returns the .vibe file whose module declaration compiles to `path`, as
 * main.vibe's `module text` compiles to main.vibe.text.js beside main.js
 * (D403), or undefined when `path` names no such output. The output is not
 * on disk: a loader serves it from the project's compile.
 */
export function moduleDeclarationSource(path) {
  return /^(.+\.vibex?)\.[^./\\]+\.jsx?$/.exec(path)?.[1]
}

// Turns one compiler run into its result:
//   outputs      Map from each .vibe source, by listed and real path, to its
//                { code, map }, and from each output of its module
//                declarations, such as main.vibe.text.js beside it, to that
//   inputs       project source files the result depends on
//   errors       all project error diagnostics; loaders select by source
//   warnings     all project warning diagnostics
// and every file the compiler read, dependencies included, for the cache.
function collect({ status, signal, output }, root, out) {
  const { files, diagnostics } = parseOutput(output, root)
  // Dependencies are contracts too; their sources change only on install.
  const inputs = files.filter((path) => !slash(path).includes("/node_modules/"))
  const errors = diagnostics.filter((diagnostic) => diagnostic.category === "error")
  const warnings = diagnostics.filter((diagnostic) => diagnostic.category === "warning")
  if (status !== 0 && !errors.length) {
    // A crash or an unknown flag prints no diagnostic; report the raw output.
    errors.push({ category: "error", code: "vibelang", text: output.trim() || `exited with ${signal || status}` })
  }
  const outputs = new Map()
  // Bundlers ask by the listed path; Node asks by the real path. A map names
  // its sources by absolute path, as bundlers expect; vibelang/register turns
  // them into file URLs for Node.
  const record = (source, emitted, name = basename(source)) => {
    const map = JSON.parse(readFileSync(emitted + ".map", "utf8"))
    map.sources = map.sources.map((entry) => slash(resolve(dirname(emitted), map.sourceRoot || "", entry)))
    map.sourceRoot = ""
    // The compiler's directive is the file's last line. A string or comment
    // earlier in the file may spell the same text, and it stays.
    const result = { code: readFileSync(emitted, "utf8").replace(/\/\/# sourceMappingURL=[^\r\n]*\s*$/, ""), map }
    outputs.set(join(dirname(source), name), result)
    outputs.set(join(dirname(realpath(source)), name), result)
  }
  const listings = new Map() // each output directory's file names
  for (const source of inputs) {
    if (!isVibeLangFile(source)) continue
    const path = relative(root, source)
    if (path.startsWith("..") || isAbsolute(path)) continue
    const stem = join(out, relative(emitRoot(root), source).replace(/\.(?:vibex?|tsx?|[cm]ts)$/, ""))
    const jsx = /\.(?:vibex|tsx)$/.test(source) && existsSync(stem + ".jsx")
    const emitted = stem + (jsx ? ".jsx" : source.endsWith(".mts") ? ".mjs" : source.endsWith(".cts") ? ".cjs" : ".js")
    // The compile emits nothing for a module it reached through node_modules,
    // such as a nested workspace package's: that one compiles with its own project.
    if (!existsSync(emitted)) continue
    record(source, emitted)
    // Each module declaration the file imports is a JavaScript module beside
    // the file's, main.vibe.text.js for module text (D403).
    const directory = dirname(emitted)
    if (!listings.has(directory)) listings.set(directory, readdirSync(directory))
    for (const name of listings.get(directory)) {
      if (moduleDeclarationSource(name) === basename(source)) record(source, join(directory, name), name)
    }
  }
  return { result: { outputs, inputs, files, errors, warnings }, files }
}

// A compiler belongs to the caller even when a launcher sits between them.
const compilerEnvironment = () => ({ ...process.env, VIBELANG_COMPILER_PARENT_PID: String(process.pid) })

const elapsed = (started) => `${Math.round(performance.now() - started)}ms`

// Times a compile's stages, in order, for the debug report.
function stopwatch() {
  const stages = []
  return {
    time(name, work) {
      const started = performance.now()
      const done = () => stages.push(`${name} ${elapsed(started)}`)
      const value = work()
      if (value instanceof Promise) return value.finally(done)
      done()
      return value
    },
    toString: () => stages.join(", ")
  }
}

// Serves a compile from the cache, or runs it and caches its result. The
// debug report names the time of each stage: the cache lookup, the snapshot of
// the inputs, the compiler process, reading its outputs, and the cache write.
function cached({ project, root, compiler, cache, debug, loader, scope = loader ? "loader" : "project" }, run) {
  const started = performance.now()
  const stages = stopwatch()
  const store = projectCache({ project, root, compiler, cache, debug, scope })
  const hit = stages.time("lookup", () => store?.lookup())
  if (hit?.result) {
    debug(`${project} from the cache in ${elapsed(started)}`)
    return hit.result
  }
  // A cold cache: the project's committed loader record (cache.mjs) serves the
  // compile when every input it names still holds, and the cache keeps it.
  const recorded = scope === "loader" && store && existsSync(loaderRecordFile(project))
    ? stages.time("record", () => loaderRecord({ project, root, compiler }).lookup()) : undefined
  if (recorded?.result) {
    stages.time("store", () => store.store(store.begin(), recorded.result, recorded.files))
    debug(`${project} from its loader record in ${elapsed(started)}: ${stages}`)
    return recorded.result
  }
  const snapshot = stages.time("snapshot", () => store?.begin())
  const finish = ({ result, files }) => {
    stages.time("store", () => store?.store(snapshot, result, files))
    const modules = new Set(result.outputs.values()).size
    const reason = hit?.miss === undefined ? "cache off" : recorded === undefined ? hit.miss : `${hit.miss}; record: ${recorded.miss}`
    debug(`compiled ${project} in ${elapsed(started)} (${reason}): ${stages}; ` +
      `${modules} ${modules === 1 ? "module" : "modules"}, ${files.length} files read`)
    return result
  }
  const compiled = run(stages)
  return compiled instanceof Promise ? compiled.then(finish) : finish(compiled)
}

/**
 * projectBackend compiles a whole tsconfig project with one vibelang process,
 * in a fresh output directory each time, or serves the result from the cache.
 * compile(project) resolves to the result described above. `cache` is false to
 * turn the cache off, or { directory } to move it.
 */
export function projectBackend({ root, compiler, cache, debug = () => {}, preserveJsx = false, [loaderScope]: loader = false }) {
  const children = new Set()
  const pending = new Set()
  let closed = false, closing

  // Give a short compile time to finish, then terminate it, escalating if it
  // ignores SIGTERM. Destroy the pipes too: an inherited writer can keep them
  // open even after the compiler has exited.
  function waitFor(work, ms) {
    let timer
    return Promise.race([work, new Promise(resolve => { timer = setTimeout(resolve, ms) })])
      .finally(() => clearTimeout(timer))
  }

  function close() {
    closed = true
    return closing ??= (async () => {
      const done = Promise.allSettled([...pending])
      await waitFor(done, 500)
      for (const child of children) child.kill("SIGTERM")
      await waitFor(done, 500)
      for (const child of children) {
        child.kill("SIGKILL")
        child.stdout.destroy()
        child.stderr.destroy()
      }
      await done
      // Node releases the ProcessWrap after invoking its close callbacks.
      await new Promise(resolve => setImmediate(resolve))
      await new Promise(resolve => setImmediate(resolve))
    })()
  }
  function run(args) {
    const [file, argv] = command(compiler, args)
    return new Promise((accept, reject) => {
      let output = "", error
      const child = spawn(file, argv, { cwd: root, env: compilerEnvironment(), stdio: ["ignore", "pipe", "pipe"] })
      children.add(child)
      child.stdout.setEncoding("utf8").on("data", (data) => { output += data })
      child.stderr.setEncoding("utf8").on("data", (data) => { output += data })
      child.on("error", (value) => { error = value })
      child.on("close", (status, signal) => {
        children.delete(child)
        if (error) reject(new Error(`vibelang: ${error.message}\nCompiler: ${compiler}`))
        else if (signal && closed) reject(new Error(`vibelang: compiler exited with ${signal}\nCompiler: ${compiler}`))
        else accept({ status, signal, output })
      })
    })
  }

  function compile(project) {
    if (closed) return Promise.reject(new Error("vibelang: compiler backend is closed"))
    const work = Promise.resolve().then(async () => {
      if (closed) throw new Error("vibelang: compiler backend is closed")
      const extra = preserveJsx ? preservedJsxArgs((await run(showConfigArgs(project))).output, preserveJsx) : []
      if (closed) throw new Error("vibelang: compiler backend is closed")
      return cached({ project, root, compiler, cache, debug, loader, ...(extra.length ? { scope: "tool-jsx" } : {}) }, async (stages) => {
        // Outside the project: webpack and esbuild rebuild when a directory they resolved through changes.
        const out = mkdtempSync(join(temporaryRoot(), "vibelang-project-"))
        try {
          const output = await stages.time("compiler", () => run(emitArgs(project, root, out, loader, extra)))
          return stages.time("collect", () => collect(output, root, out))
        } finally {
          // Outputs are in memory now. The next compile starts from an empty directory.
          rmSync(out, { recursive: true, force: true })
        }
      })
    })
    pending.add(work)
    work.then(() => pending.delete(work), () => pending.delete(work))
    return work
  }

  return { compile, close }
}

/**
 * compileProjectSync is projectBackend's compile for callers that cannot wait,
 * such as Node's synchronous module hooks.
 */
export function compileProjectSync({ project, root = packageRoot(project), compiler = findCompiler(root), cache, debug = () => {}, preserveJsx = false, [loaderScope]: loader = false }) {
  let extra = []
  if (preserveJsx) {
    const [file, argv] = command(compiler, showConfigArgs(project))
    const run = spawnSync(file, argv, { cwd: dirname(project), encoding: "utf8", maxBuffer: 1 << 30 })
    if (run.error) throw new Error(`vibelang: ${run.error.message}\nCompiler: ${compiler}`)
    extra = preservedJsxArgs(run.stdout, preserveJsx)
  }
  if (extra.length) return cached({ project, root, compiler, cache, debug, loader, scope: "tool-jsx" }, (stages) => compileOnce(project, root, compiler, stages, loader, extra))
  return cached({ project, root, compiler, cache, debug, loader }, (stages) => compileOnce(project, root, compiler, stages, loader))
}

const showConfigArgs = (project) => ["--project", project, "--showConfig"]

// The options that leave JSX in a project's output for a tool that reads JSX,
// as the React Compiler must: lowered, an event handler is an argument to an
// unknown call. A project's own automatic runtime still types its JSX, so the
// project checks as it does when lowered. Nothing for any other jsx setting: a
// classic project's factory is its compile's to apply. `preserveJsx: "react"`
// is for a host that lowers JSX to React's runtime alone, as Vite's Oxc does: a
// project on another runtime keeps its lowered output there.
function preservedJsxArgs(config, preserveJsx) {
  let options
  try { options = JSON.parse(config).compilerOptions ?? {} } catch { return [] } // the project compile reports invalid config
  if (options.jsx !== "react-jsx" && options.jsx !== "react-jsxdev") return []
  const source = options.jsxImportSource ?? "react"
  return preserveJsx === "react" && source !== "react" ? [] : ["--jsx", "preserve", "--jsxImportSource", source]
}

// One compiler run over a project, as a loader runs it.
function compileOnce(project, root, compiler, stages = stopwatch(), loader = true, extra = []) {
  const out = mkdtempSync(join(temporaryRoot(), "vibelang-project-"))
  try {
    const [file, argv] = command(compiler, emitArgs(project, root, out, loader, extra))
    const run = stages.time("compiler", () => spawnSync(file, argv, { cwd: root, env: compilerEnvironment(), encoding: "utf8", maxBuffer: 1 << 30 }))
    if (run.error) throw new Error(`vibelang: ${run.error.message}\nCompiler: ${compiler}`)
    return stages.time("collect", () => collect({ status: run.status, signal: run.signal, output: run.stdout + run.stderr }, root, out))
  } finally {
    rmSync(out, { recursive: true, force: true })
  }
}

/**
 * writeLoaderRecord compiles a project as the loaders do and commits the
 * result as its loader record, <project dir>/.vibelang/js/.loader/<name>.json
 * (cache.mjs), so a process with a cold cache loads the project's .vibe
 * modules without compiling them while every input is unchanged. The migrate
 * flow writes one with the package's emitted JavaScript. Returns { file,
 * modules }, or { errors } when the project does not compile, which leaves no
 * record. An input that changes during the compile is retried twice.
 */
export function writeLoaderRecord({ project, root = packageRoot(project), compiler = findCompiler(root) }) {
  project = resolve(project)
  const record = loaderRecord({ project, root: resolve(root), compiler })
  rmSync(record.file, { force: true })
  for (let attempt = 1; ; attempt++) {
    const snapshot = record.begin()
    const { result, files } = compileOnce(project, resolve(root), compiler)
    if (result.errors.length) return { errors: result.errors }
    try {
      const file = record.write(snapshot, result, files)
      return { file, modules: new Set(result.outputs.values()).size }
    } catch (error) {
      if (attempt === 3 || !/changed during or too close/.test(error.message)) throw error
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 120)
    }
  }
}

/**
 * checkLoaderRecord checks a project's loader record against the current tree
 * as a loader with a cold cache does: { modules } when every input holds, else
 * { miss } naming the first that does not. The migrate flow checks each record
 * once every package is emitted and routed.
 */
export function checkLoaderRecord({ project, root = packageRoot(project), compiler = findCompiler(root) }) {
  project = resolve(project)
  const found = loaderRecord({ project, root: resolve(root), compiler }).lookup()
  return found.miss !== undefined ? { miss: found.miss } : { modules: new Set(found.result.outputs.values()).size }
}

// The preferred config in directory, or undefined. A custom name such as
// tsconfig.app.json is never discovered, as in TypeScript: it must be named.
const configIn = (directory) =>
  ["vibe.config.json", "tsconfig.json", "jsconfig.json"].map((name) => join(directory, name)).find((path) => existsSync(path))

/** Returns the preferred config in the nearest directory above file, or undefined. */
export function nearestProject(file) {
  for (let directory = dirname(resolve(file)); ; directory = dirname(directory)) {
    const config = configIn(directory)
    if (config !== undefined) return config
    if (dirname(directory) === directory) return undefined
  }
}

/**
 * Returns the directory of the package that holds `path`: the nearest above it
 * with a package.json, else path's own directory. A project of a package
 * compiles from here, so a worker/tsconfig.json that includes ../db emits db's
 * modules too.
 */
export function packageRoot(path) {
  path = resolve(path)
  for (let directory = dirname(path); ; directory = dirname(directory)) {
    if (existsSync(join(directory, "package.json"))) return directory
    if (dirname(directory) === directory) return dirname(path)
  }
}

/**
 * workspaceProject names the project to try first for a module when `project`
 * (whose directory is `root`) is the one asked for: the nearest config above
 * the module, as TypeScript's language service starts, and `project` where
 * that config would be root's own. A module of another workspace package,
 * outside root or nested inside it with its own package.json, gets its
 * package's project. findProject takes over when this one leaves the module out.
 */
export function workspaceProject(file, root, project) {
  const path = relative(root, file)
  if (path.startsWith("..") || isAbsolute(path)) return nearestProject(file) ?? project
  // A nested package without a config of its own, such as a test fixture, stays in project.
  for (let directory = dirname(file); directory !== root && dirname(directory) !== directory; directory = dirname(directory)) {
    const own = configIn(directory)
    if (own !== undefined) return own
    if (existsSync(join(directory, "package.json"))) return project
  }
  return project
}

// Every config in a package, sorted by path: not in node_modules or a dot
// directory, and not in a nested package, which owns its modules.
function packageConfigs(directory) {
  const found = []
  const visit = (current) => {
    const own = configIn(current)
    if (own !== undefined) found.push(own)
    for (const entry of readdirSync(current, { withFileTypes: true })) {
      if (!entry.isDirectory() || entry.name === "node_modules" || entry.name.startsWith(".")) continue
      const child = join(current, entry.name)
      if (!existsSync(join(child, "package.json"))) visit(child)
    }
  }
  visit(directory)
  return found.sort()
}

// The configs a config's `references` name.
function referencesOf(tsconfig) {
  let config
  try {
    config = parseJsonc(readFileSync(tsconfig, "utf8"))
  } catch {
    return []
  }
  return (Array.isArray(config.references) ? config.references : []).filter((reference) => typeof reference?.path === "string").map((reference) => {
    const target = resolve(dirname(tsconfig), reference.path)
    return target.endsWith(".json") ? target : join(target, "tsconfig.json")
  })
}

/**
 * findProject names the project for a module that `tried` left out, by
 * TypeScript's search for a file's default project: each config from the
 * module's directory up to its package's, each followed by its references,
 * breadth first (`project`, the one asked for, is last among them). TypeScript
 * ends with the open projects that hold the file, first by path. A loader has
 * none open, so it asks every config of the module's package, by path, and
 * prefers one whose include lists the module over one that only imports it:
 * the importer's options are not the ones the module was written for.
 *
 * Returns { project, searched }: project is undefined when none holds the
 * module, and searched names the configs it asked. `programs` keeps each
 * config's listing, which runs the compiler, for the caller's next module.
 */
export function findProject(file, { project, tried, compiler, programs = new Map() }) {
  file = moduleDeclarationSource(file) ?? file
  const paths = new Set([file, realpath(file)])
  const scope = packageRoot(nearestProject(file) ?? file)
  const searched = new Set()
  const programOf = (tsconfig) => {
    searched.add(tsconfig)
    if (!programs.has(tsconfig)) programs.set(tsconfig, projectProgram({ project: tsconfig, compiler }))
    return programs.get(tsconfig)
  }
  // TypeScript's configured-project search rejects an indirect inclusion in a
  // composite reference. Ask the compiler for merged options, including extends.
  const compositeReference = (tsconfig) => {
    const program = programOf(tsconfig)
    if (program.composite === undefined) {
      const [executable, args] = command(compiler ?? findCompiler(dirname(tsconfig)), ["--project", tsconfig, "--showConfig"])
      const run = spawnSync(executable, args, { cwd: dirname(tsconfig), encoding: "utf8", maxBuffer: 1 << 30 })
      if (run.error) throw new Error(`vibelang: ${run.error.message}\nCompiler: ${compiler}`)
      try { program.composite = JSON.parse(run.stdout).compilerOptions?.composite === true }
      catch { program.composite = false } // the project compile reports invalid config diagnostics
    }
    return program.composite
  }
  // A project compiles from its package, so another package's can't emit this module.
  const serves = (tsconfig) => {
    const path = relative(packageRoot(tsconfig), file)
    return tsconfig !== tried && !path.startsWith("..") && !isAbsolute(path)
  }
  const holds = (tsconfig, list) => serves(tsconfig) && programOf(tsconfig)[list].some((path) => paths.has(path))
  const starts = []
  for (let directory = dirname(file); ; directory = dirname(directory)) {
    const config = configIn(directory)
    if (config !== undefined) starts.push(config)
    if (directory === scope || dirname(directory) === directory) break
  }
  if (project !== undefined) starts.push(project)
  const visited = new Set()
  for (const start of starts) {
    const queue = [start]
    for (const tsconfig of queue) {
      if (visited.has(tsconfig)) continue
      visited.add(tsconfig)
      if (holds(tsconfig, "files") && (tsconfig === start || !compositeReference(tsconfig) || holds(tsconfig, "roots"))) return { project: tsconfig, searched: [...searched] }
      queue.push(...referencesOf(tsconfig))
    }
  }
  const rest = packageConfigs(scope).filter((tsconfig) => !visited.has(tsconfig))
  const found = rest.find((tsconfig) => holds(tsconfig, "roots")) ?? rest.find((tsconfig) => holds(tsconfig, "files"))
  return { project: found, searched: [...searched] }
}

// Compare the config across the compile, including persistent stat failures.
function fileState(file) {
  try {
    const { mtimeMs, ctimeMs, size, ino } = statSync(file)
    return JSON.stringify([mtimeMs, ctimeMs, size, ino])
  } catch (error) {
    return error.code
  }
}

// Returns a source modified after time, or one that is gone.
function changedSince(files, time) {
  for (const file of files) {
    try {
      const mtime = statSync(file).mtimeMs
      if (mtime > time) return { file, mtime }
    } catch (error) {
      return { file, error: error.code }
    }
  }
}

// Module code for a failed compile. The bundler reports the real error.
const failed = "throw new Error(\"vibelang: this module did not compile; see the build errors\")\n"

/**
 * projects compiles .vibe modules for a bundler, one whole-project compile per
 * tsconfig. A module belongs to the nearest config above it, which is `project`
 * for root's own directories, and to the one findProject names when that config
 * leaves it out. Each project compiles once per revision; invalidate() starts a
 * new revision.
 *
 * load(file) resolves to { project, code, map, inputs, errors, warnings, first, error }.
 * errors and warnings belong to the loaded source or are project-wide.
 * first is true for the first module loaded from that compile. `error`
 * says that no project includes the module. `cache` is as for
 * projectBackend: a compile a revision needs may come from the cache.
 */
export function projects({ root, project, compiler, cache, debug = () => {}, preserveJsx = false }) {
  const states = new Map()
  let revision = 0
  let closed = false, closing

  // What findProject learned this revision: each module it moved, and each listing.
  const moved = new Map(), programs = new Map()
  let searchedIn = revision

  function forgetStale() {
    if (searchedIn === revision) return
    searchedIn = revision
    moved.clear()
    programs.clear()
  }

  const projectOf = (file) => {
    file = resolve(file)
    forgetStale()
    return moved.get(file) ?? workspaceProject(file, root, project)
  }

  function stateOf(tsconfig) {
    let state = states.get(tsconfig)
    if (state === undefined) {
      const projectRoot = tsconfig === project ? root : packageRoot(tsconfig)
      state = { tsconfig, backend: projectBackend({ root: projectRoot, compiler, cache, debug, preserveJsx, [loaderScope]: true }), result: undefined, pending: undefined, compiled: -1, reported: -1 }
      states.set(tsconfig, state)
    }
    return state
  }

  async function compiled(state) {
    while (state.compiled !== revision) {
      if (closed) throw new Error("vibelang: projects are closed")
      if (!state.pending) {
        const started = revision
        // File mtimes retain fractional milliseconds. An integer Date.now()
        // can precede a save that already happened in this same millisecond.
        const time = performance.timeOrigin + performance.now()
        const configBefore = fileState(state.tsconfig)
        debug(`compile ${state.tsconfig} ${started} started`)
        state.pending = state.backend.compile(state.tsconfig)
          .then((value) => {
            state.result = value
            state.compiled = started
            debug(`compile ${state.tsconfig} ${started} finished in ${Math.round(performance.timeOrigin + performance.now() - time)}ms: ${value.outputs.size} outputs, ${value.errors.length} errors`)
            // A file saved during the compile may be missing from its output. esbuild records
            // watch files when a load returns, so it would not rebuild for that save. Compile again.
            const changed = fileState(state.tsconfig) !== configBefore
              ? { file: state.tsconfig, error: "config state changed" }
              : changedSince(value.inputs.filter((file) => file !== state.tsconfig), time)
            if (changed) {
              revision++
              debug(`${changed.file} changed during compile ${started}: revision ${revision}; mtime=${changed.mtime ?? changed.error}, started=${time}`)
            }
          })
          .finally(() => { state.pending = undefined })
      }
      await state.pending
    }
    return state.result
  }

  return {
    projectOf,
    /** Finishes or stops all compiles and releases their process and pipe handles. */
    close() {
      closed = true
      return closing ??= (async () => {
        await Promise.all([...states.values()].map(async state => {
          await state.backend.close()
          await Promise.allSettled([state.pending])
        }))
        states.clear()
      })()
    },
    /** Starts a new revision: every project compiles again on its next load. */
    invalidate() {
      revision++
      debug(`invalidate: revision ${revision}`)
    },
    async load(file) {
      if (closed) throw new Error("vibelang: projects are closed")
      // Vite uses forward slashes on Windows; compiler output keys use native paths.
      file = resolve(file)
      let state = stateOf(projectOf(file))
      let result = await compiled(state)
      let others = []
      if (!result.outputs.has(file)) {
        const found = findProject(file, { project, tried: state.tsconfig, compiler, programs })
        others = found.searched
        if (found.project !== undefined) {
          moved.set(file, found.project)
          state = stateOf(found.project)
          result = await compiled(state)
        }
      }
      const { outputs, inputs } = result
      const errors = diagnosticsForFile(result.errors, file, result.files)
      const warnings = diagnosticsForFile(result.warnings, file, result.files)
      // Keep the public first-module flag independent of source diagnostics.
      const first = state.reported !== state.compiled
      state.reported = state.compiled
      if (errors.length) return { project: state.tsconfig, code: failed, inputs, errors, warnings, first }
      const output = outputs.get(file)
      return {
        project: state.tsconfig, code: output?.code ?? failed, map: output?.map, inputs, errors, warnings, first,
        error: !output && {
          message: `vibelang: ${file} is not part of ${[state.tsconfig, ...others].join(" or ")}. Add it to the tsconfig's include.`, id: file
        }
      }
    }
  }
}

/** The executable and arguments that run the compiler with args. */
export { command as compilerCommand }
