import { aliasImport } from "./paths-imports.js"
import { extensionlessImport } from "./relative-imports.js"
import { existsSync, readFileSync, realpathSync } from "node:fs"
import { createRequire } from "node:module"
import { isVibeLangFile } from "./vibe-directive.js"
import { dirname, isAbsolute, join, resolve } from "node:path"
import { fileURLToPath, pathToFileURL } from "node:url"

// Vite's default resolve.extensions, which a config that sets none uses.
const viteExtensions = [".mjs", ".js", ".mts", ".ts", ".jsx", ".tsx", ".json"]

// Preserve the host's native defaults when the user supplied no conditions.
// Vite concatenates arrays returned by config hooks with the user's arrays.
// Vitest's defaults leave out `module` (its getDefaultServerConditions): it
// passes its server conditions to the Node processes that run tests as
// --conditions, and a package's `module` export is often bundler-only ESM.
// Vite's own, `module` included, made Node load @opentelemetry/api's build/esm
// in Smithers' tests. Vitest sets VITEST before it loads the config.
function sourceConditionConfig(config) {
  const condition = "vibelang-source"
  const conditions = (current, defaults) => current?.includes(condition) ? {} : { conditions: [...(current ? [] : defaults), condition] }
  const vitest = process.env.VITEST === "true" && !config.test?.browser?.enabled
  return {
    resolve: conditions(config.resolve?.conditions, vitest ? ["node", "development|production"] : ["module", "browser", "development|production"]),
    ssr: { resolve: conditions(config.ssr?.resolve?.conditions, vitest ? ["node", "development|production"] : ["module", "node", "development|production"]) }
  }
}

const cleanId = (id) => id.split("?")[0]

// Emitted relative imports are URLs; bundler hooks resolve filesystem names.
// Decode once so a literal percent sequence retains its filename spelling.
function outputPath(source, importer, written) {
  if (!importer || !isCompiled(cleanId(importer)) || !source.startsWith(".") || !/\.jsx?$/.test(source)) return source
  let decoded
  try { decoded = decodeURIComponent(source) } catch { return source }
  if (decoded === source) return source
  // Authored .js imports retain TypeScript's literal filename spelling,
  // including when only a declaration file exists for the runtime module.
  if (written(source, importer)) return source
  return decoded
}

const isSource = isVibeLangFile
// A JSX-shaped id lets the framework's ordinary JSX filter see compiler output.
function jsxSource(file) {
  if (file.endsWith(".vibex.jsx") && !existsSync(file) && existsSync(file.slice(0, -4))) return file.slice(0, -4)
}
const sourceFile = (file) => jsxSource(file) ?? file
const servedId = (file) => file.endsWith(".vibex") ? file + ".jsx" : file

// Vite's own module queries: ?import on a JavaScript import of a non-JS
// extension, ?v= and ?t= for versioning and hot updates, and the worker
// entry's ?worker_file&type=. An id that carries only these is the module
// itself. Any other query, such as x.vibe?highlighted or ?raw, names a
// resource another plugin (or Vite) loads from the same source. Vite's
// TypeScript transform rewrites the code that loader supplied, so such a
// resource keeps its content; this plugin compiles the .vibe source itself,
// so it leaves those ids alone instead of replacing the loaded module.
const viteQueries = new Set(["import", "v", "t", "worker_file", "type"])
function isModuleId(id) {
  const query = id.indexOf("?")
  if (query < 0) return true
  for (const key of new URLSearchParams(id.slice(query + 1)).keys()) {
    if (!viteQueries.has(key)) return false
  }
  return true
}
const slash = (path) => path.replaceAll("\\", "/")

// A module declaration of main.vibe compiles to main.vibe.text.js beside it
// (D403), and one in a .vibex file to .jsx under preserved JSX. Neither is on
// disk: the project's compile serves it. The pattern is vibelang/project's
// moduleDeclarationSource.
function isModuleOutput(path) {
  const source = /^(.+\.vibex?)\.[^./\\]+\.jsx?$/.exec(path)?.[1]
  return source !== undefined && !existsSync(path) && existsSync(source)
}
// A module whose JavaScript the plugin compiles: a .vibe module or one of its module declarations.
const isCompiled = (path) => isSource(sourceFile(path)) || isModuleOutput(path)

// The tsconfig.json nearest above directory, whose paths apply to its modules.
const configs = new Map()
function nearestConfig(directory) {
  if (!configs.has(directory)) {
    const own = join(directory, "tsconfig.json")
    const parent = dirname(directory)
    configs.set(directory, existsSync(own) ? own : parent === directory ? undefined : nearestConfig(parent))
  }
  return configs.get(directory)
}

// The compiler writes this declaration beside its owning source while serving
// JavaScript. It is output, not a new input that should invalidate that compile.
// A hand-written declaration without a companion remains a TypeScript input.
function isGeneratedDeclaration(path) {
  for (const extension of [".vibe", ".vibex"]) {
    const suffix = ".d" + extension + ".ts"
    if (path.endsWith(suffix) && existsSync(path.slice(0, -suffix.length) + extension)) return true
  }
  return false
}

// Keep TypeScript's source priority when the bundler cannot find .vibe.
function extensionlessVibe(directory, specifier) {
  const source = extensionlessImport(directory, specifier)
  return source && isSource(source) ? source : undefined
}

// The compile backend is the vibelang package's own: the project's install
// first, so it matches the compiler that runs, else the one beside this plugin.
async function loadBackend(root) {
  for (const base of [join(root, "package.json"), fileURLToPath(import.meta.url)]) {
    let path
    try {
      path = createRequire(base).resolve("vibelang/project")
    } catch {
      continue
    }
    return import(pathToFileURL(path).href)
  }
  throw new Error("vibelang-vite needs the vibelang package: npm install --save-dev vibelang")
}

// The absolute path of a vibelang module, so a process started in any
// directory finds it.
function vibelangModule(root, name) {
  for (const base of [join(root, "package.json"), fileURLToPath(import.meta.url)]) {
    try {
      return createRequire(base).resolve(name)
    } catch {
      continue
    }
  }
  throw new Error("vibelang-vite's register option needs the vibelang package: npm install --save-dev vibelang")
}

// Adds flag to the variable name of the tests' environment, keeping what the
// config or the environment already sets; undefined when it is already there.
function withOption(env, name, flag) {
  const inherited = env?.[name] ?? process.env[name] ?? ""
  return inherited.includes(flag) ? undefined : [inherited, flag].filter(Boolean).join(" ")
}

// VIBELANG_VITE_DEBUG=1 traces whole-project compiles and invalidations.
const debug = process.env.VIBELANG_VITE_DEBUG ? (text) => console.error(`vibelang-vite: ${text}`) : () => {}

// Vite pre-bundles the bare imports its dependency scan finds before the first
// request. An import found later, on a request, makes Vite optimize again and
// reload the page, which can fail a browser test running on it. The scan
// (Vite's src/node/optimizer/scan.ts: esbuild on Vite 7, Rolldown on Vite 8)
// resolves through the plugins' resolveId but runs no plugin's load or
// transform, and it follows only a module that is JavaScript, HTML or has an
// extension in optimizeDeps.extensions. The plugins in
// optimizeDeps.esbuildOptions (Vite 7) or optimizeDeps.rolldownOptions (Vite 8,
// whose plugin context has meta.rolldownVersion) run before the scanner's own.
// A .vibe module's source names none of the imports its JavaScript adds, such
// as effect/Schema for a schema, so the scan reads that JavaScript.
// A module declaration of a .vibex file outputs .jsx under preserved JSX, as in
// isModuleOutput; without it the scanner reads the absent file and fails.
const scannedId = /\.(?:vibex?(?:\.jsx|\.[^./\\]+\.jsx?)?|tsx?|[cm]ts)$/
function scanConfig(config, meta, load) {
  const extensions = [".vibe", ".vibex"].filter(extension => !config.optimizeDeps?.extensions?.includes(extension))
  const scan = async (file) => isCompiled(file) ? load(file) : undefined
  if (meta?.rolldownVersion) {
    return { extensions, rolldownOptions: { plugins: [{ name: "vibelang:scan", load: { filter: { id: scannedId },
      async handler(id) { const code = await scan(cleanId(id)); return code === undefined ? undefined : { code, moduleType: /\.(?:vibex|tsx)/.test(cleanId(id)) ? "jsx" : "js" } } } }] } }
  }
  return { extensions, esbuildOptions: { plugins: [{ name: "vibelang:scan", setup(build) {
    build.onLoad({ filter: scannedId }, async ({ path }) => {
      const contents = await scan(path)
      return contents === undefined ? undefined : { contents, loader: /\.(?:vibex|tsx)/.test(path) ? "jsx" : "js" }
    })
  } }] } }
}

// Main and worker bundles create separate plugin instances in one Vite
// process. Share their whole-project compiles while any instance uses them.
// Backend identity keeps different installed compiler packages independent.
const sharedProjects = new WeakMap()
let nextManager = 0
async function acquireProjects(backend, options) {
  let managers = sharedProjects.get(backend)
  if (!managers) sharedProjects.set(backend, managers = new Map())
  const key = JSON.stringify([options.root, options.project, options.compiler])
  let entry
  while ((entry = managers.get(key))?.closing) await entry.closing
  if (!entry) {
    const id = ++nextManager
    entry = { id, users: 0, projects: backend.projects({ preserveJsx: "react",
      ...options, debug: text => debug(`manager ${id}: ${text}`)
    }) }
    managers.set(key, entry)
  }
  entry.users++
  debug(`manager ${entry.id}: acquire, ${entry.users} consumers`)
  let released = false, closing
  return {
    ...entry.projects,
    close() {
      if (released) return closing
      released = true
      entry.users--
      debug(`manager ${entry.id}: release, ${entry.users} consumers`)
      if (entry.users === 0) {
        closing = entry.closing = Promise.resolve().then(() => entry.projects.close()).finally(() => {
          if (managers.get(key) === entry) managers.delete(key)
        })
      }
      return closing
    }
  }
}

/** @param {import('./index.d.ts').VibeLangOptions} options */
export default function vibelang(options = {}) {
  let root, project, logger, backend, modules, current, closing

  // One compile per tsconfig: the project for root's modules, and each
  // workspace package's own for modules outside root.
  function loaded() {
    modules ??= Promise.resolve(closing).then(() => loadBackend(root)).then(async (value) => {
      backend = value
      current = await acquireProjects(backend, { root, project, compiler: backend.findCompiler(root, options.compiler), debug })
      return current
    })
    return modules
  }

  const writtenImports = new Map()
  function writtenOutput(source, importer) {
    const file = sourceFile(cleanId(importer))
    const selected = current?.projectOf?.(file) ?? backend.nearestProject(file) ?? project
    const canonical = path => { try { return realpathSync(path) } catch { return resolve(path) } }
    const from = canonical(file)
    const text = readFileSync(file, "utf8")
    let entry = writtenImports.get(from)
    if (entry?.project !== selected || entry.text !== text) {
      const result = backend.projectImports({ root: backend.packageRoot(selected), project: selected, compiler: backend.findCompiler(root, options.compiler) })
      entry = { project: selected, text, imports: new Set(result.imports.filter(item => canonical(item.importer) === from).map(item => cleanId(item.specifier))) }
      writtenImports.set(from, entry)
    }
    const written = entry.imports.has(source)
    debug(`relative output name from ${file}: ${written ? "written import" : "rewritten import"}`)
    return written
  }

  function close() {
    writtenImports.clear()
    const pending = modules
    modules = undefined
    current = undefined
    const work = Promise.resolve(closing).then(async () => {
      const projects = await pending
      await projects?.close()
    })
    closing = work
    return work
  }

  // The JavaScript the scan reads. A module that does not compile scans as
  // empty, as Vite's scanner treats a file it cannot read; its request reports
  // the diagnostics.
  async function scanned(file) {
    try {
      const { code } = await (await loaded()).load(sourceFile(file))
      return code ?? ""
    } catch {
      return ""
    }
  }

  function diagnostics(errors, file) {
    const first = errors.find((diagnostic) => diagnostic.file) || {}
    return {
      message: errors.map(backend.formatDiagnostic).join("\n"),
      id: first.file || file,
      loc: first.file && { file: first.file, line: first.line, column: first.column - 1 }
    }
  }

  async function hotUpdate(context, environment) {
    if (isGeneratedDeclaration(context.file)) { debug(`ignore generated declaration ${context.file}`); return [] }
    if (!/\.(?:vibex?|[cm]?tsx?)$/.test(context.file) && !context.file.endsWith(".json")) return
    const graph = environment?.moduleGraph ?? context.server.moduleGraph
    const channel = environment?.hot ?? context.server.ws
    debug(`hot ${context.type ?? "update"} ${context.file}; environment=${environment?.name ?? "legacy"}, modules=${context.modules.length}`)
    const projects = await loaded()
    projects.invalidate()
    // Any source can change the contracts used to compile a .vibe importer.
    const affected = new Set()
    const visit = (module) => {
      if (affected.has(module)) return
      affected.add(module)
      for (const importer of module.importers) visit(importer)
    }
    for (const module of context.modules) visit(module)
    for (const module of graph.idToModuleMap.values()) {
      if (module.file && isCompiled(module.file)) visit(module)
    }
    for (const module of affected) graph.invalidateModule(module)
    // Recompile the sources Vite has loaded. A watched TypeScript source
    // can change their contracts without making its own errors loader errors.
    const errors = []
    const sources = new Set([...affected].map((module) => module.file).filter((file) => file && isCompiled(file)))
    for (const file of sources) errors.push(...(await projects.load(sourceFile(file))).errors)
    if (errors.length) {
      const { message, id, loc } = diagnostics(errors, context.file)
      context.server.config.logger.error(message)
      channel.send({ type: "error", err: { message, stack: "", plugin: "vibelang", id, loc } })
      return []
    }
    return [...affected]
  }

  return {
    name: "vibelang",
    enforce: "pre",
    config(config) {
      // An extensionless import, or a directory's index (`./mount` for
      // mount/index.vibe), reaches a .vibe module as it reaches a .ts one.
      // Vite concatenates a plugin's arrays with the config's.
      const extensions = config.resolve?.extensions
      const added = sourceConditionConfig(config)
      added.optimizeDeps = scanConfig(config, this?.meta, scanned)
      const missing = [".vibe", ".vibex"].filter(extension => !extensions?.includes(extension))
      if (missing.length) added.resolve.extensions = extensions ? missing : [...viteExtensions, ...missing]
      if (!options.register) return added
      // Vitest copies test.env into process.env, which the processes a test
      // starts inherit: node reads NODE_OPTIONS, and bun, such as
      // process.execPath under bun x --bun vitest, reads BUN_OPTIONS, whose
      // --preload takes a path without spaces.
      const base = resolve(config.root || process.cwd())
      const preload = vibelangModule(base, "vibelang/bun")
      const env = {
        NODE_OPTIONS: withOption(config.test?.env, "NODE_OPTIONS", `--import=${pathToFileURL(vibelangModule(base, "vibelang/register")).href}`),
        BUN_OPTIONS: /\s/.test(preload) ? undefined : withOption(config.test?.env, "BUN_OPTIONS", `--preload=${preload}`)
      }
      for (const name of Object.keys(env)) if (env[name] === undefined) delete env[name]
      return Object.keys(env).length ? { ...added, test: { env } } : added
    },
    // Vitest's fsModuleCache keys a transform by the module's own text, but a
    // .vibe module's JavaScript also depends on the compiler and on the
    // contracts of the modules it imports, so a rerun would serve JavaScript
    // compiled against an earlier contract. The project compile has its own
    // cache (vibelang/cache), keyed by every input.
    configureVitest(context) {
      const define = context.defineCacheKeyGenerator ?? context.experimental_defineCacheKeyGenerator
      define?.(({ id }) => isCompiled(cleanId(id)) && isModuleId(id) ? false : undefined)
    },
    configResolved(config) {
      root = config.root
      project = resolve(root, options.project || "tsconfig.json")
      logger = config.logger
    },
    configureServer(server) {
      // Vite otherwise treats an unknown extension as a static asset on HTTP.
      server.middlewares.use((request, _response, next) => {
        const url = new URL(request.url || "/", "http://localhost")
        if (isSource(url.pathname) && !url.searchParams.has("raw") && !url.searchParams.has("url")) {
          url.searchParams.set("import", "")
          request.url = url.pathname + url.search
        }
        next()
      })
    },
    resolveId(source, importer, resolveOptions) {
      const original = cleanId(source)
      const query = source.slice(original.length)
      const file = outputPath(original, importer, writtenOutput)
      const serve = target => slash(isModuleId(source) ? servedId(target) : target) + query
      if (isModuleId(source) && /\.vibex(?:\.jsx)?$/.test(file) && (isAbsolute(file) || file.startsWith("."))) {
        const candidates = isAbsolute(file) ? [file, ...(root ? [resolve(root, "." + file)] : [])] :
          importer ? [resolve(dirname(cleanId(importer)), file)] : []
        for (const target of candidates) {
          if (jsxSource(target)) return slash(target) + query
          if (target.endsWith(".vibex") && existsSync(target)) return serve(target)
        }
      }
      if (!importer) return
      if (!source.startsWith(".")) {
        if (isCompiled(cleanId(importer))) {
          const target = aliasImport(nearestConfig(dirname(cleanId(importer))), file)
          if (target !== undefined) return serve(target)
        }
        // A package's exports can name JSX source even when its import is bare.
        if (this.resolve) return this.resolve(source, importer, { ...resolveOptions, skipSelf: true }).then(resolved => {
          if (resolved && isModuleId(source) && cleanId(resolved.id).endsWith(".vibex")) return { ...resolved, id: servedId(cleanId(resolved.id)) + resolved.id.slice(cleanId(resolved.id).length) }
          return resolved
        })
        return
      }
      const vibe = extensionlessVibe(dirname(cleanId(importer)), file)
      if (vibe !== undefined) return serve(vibe)
      // Emitted imports keep the original source in Vite's module graph.
      if (!/\.jsx?$/.test(file)) return
      const target = resolve(dirname(cleanId(importer)), file)
      if (existsSync(target)) return file !== original
        ? this.resolve(file + query, importer, { ...resolveOptions, skipSelf: true }) : undefined
      if (isModuleOutput(target)) return slash(target) + query
      const stem = target.replace(/\.jsx?$/, "")
      for (const extension of file.endsWith(".jsx") ? [".vibex"] : [".vibe", ".vibex"]) {
        const source = stem + extension
        if (existsSync(source)) return serve(source)
      }
      if (file !== original) return this.resolve(file + query, importer, { ...resolveOptions, skipSelf: true })
    },
    // A module declaration's JavaScript comes from its .vibe file's compile.
    async load(id) {
      const file = cleanId(id)
      if ((!isModuleOutput(file) && !jsxSource(file)) || !isModuleId(id)) return
      const { project, code, map, errors, warnings, error } = await (await loaded()).load(sourceFile(file))
      this.addWatchFile(project)
      if (jsxSource(file)) this.addWatchFile(sourceFile(file))
      if (errors.length) this.error(diagnostics(errors, file))
      for (const warning of warnings) logger.warn(backend.formatDiagnostic(warning))
      if (error) this.error(error)
      // Vite relativizes sources and annotates maps in place. The backend
      // caches these objects across requests, so each caller owns its copy.
      return { code, map: structuredClone(map) }
    },
    async transform(_source, id) {
      const file = cleanId(id)
      if (!isSource(file) || !isModuleId(id)) return
      const { project, code, map, errors, warnings, error } = await (await loaded()).load(sourceFile(file))
      this.addWatchFile(project)
      // Reject diagnostics for this source, including on repeated requests.
      if (errors.length) this.error(diagnostics(errors, file))
      for (const warning of warnings) logger.warn(backend.formatDiagnostic(warning))
      if (error) this.error(error)
      return { code, map: structuredClone(map) }
    },
    watchChange(id) {
      if (isGeneratedDeclaration(id)) { debug(`ignore generated declaration ${id}`); return }
      if (/\.(?:vibex?|[cm]?tsx?|json)$/.test(id)) current?.invalidate()
    },
    async hotUpdate(context) {
      return hotUpdate(context, this.environment)
    },
    async handleHotUpdate(context) {
      return hotUpdate(context)
    },
    closeBundle: close,
    closeWatcher: close
  }
}
