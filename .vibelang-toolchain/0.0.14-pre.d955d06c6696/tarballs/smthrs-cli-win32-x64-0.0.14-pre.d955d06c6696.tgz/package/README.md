# @smthrs/cli-win32-x64

> **Warning:** VibeLang is v0. The language will change in major, breaking ways. It is not suitable for production use.

The native VibeLang compiler for win32 on x64. Install [`vibelang`](https://www.npmjs.com/package/vibelang) instead: it lists this package as an optional dependency, and npm installs the one that matches your platform.
