export interface Diagnostic {
  readonly file?: string
  readonly line?: number
  readonly column?: number
  readonly category: "error" | "warning"
  readonly code: string
  text: string
}

export interface Output {
  readonly code: string
  readonly map: { sources: Array<string>; sourceRoot: string; [key: string]: unknown }
}

export interface Result {
  /**
   * Each .vibe source, by listed and real path, to its JavaScript and source
   * map, and each output of its module declarations, such as main.vibe.text.js
   * beside main.vibe, to that module's.
   */
  readonly outputs: Map<string, Output>
  /** Project source files the result depends on. */
  readonly inputs: Array<string>
  /** Every file the compiler listed, including dependencies. */
  readonly files: Array<string>
  /** All project errors that fail a `vibelang -p` build; emitted outputs may still be available. */
  readonly errors: Array<Diagnostic>
  /**
   * All other project diagnostics: warnings, and errors the build's exit status
   * leaves out, such as imported Effect lint errors under the plugin's
   * `ignoreEffectErrorsInTscExitCode`.
   */
  readonly warnings: Array<Diagnostic>
}

export interface Loaded {
  /** The tsconfig whose compile served the module. */
  readonly project: string
  readonly code: string
  readonly map?: Output["map"]
  readonly inputs: Array<string>
  /** Errors for this source and project-wide errors. The module's code throws when there are any. */
  readonly errors: Array<Diagnostic>
  /** Warnings and build-ignored errors (see Result.warnings) for this source, and project-wide ones. */
  readonly warnings: Array<Diagnostic>
  /** True for the first module loaded from this compile. */
  readonly first: boolean
  /** Set when the project does not include the module. */
  readonly error?: false | { readonly message: string; readonly id: string }
}

export interface Import {
  /** The file that writes the import. */
  readonly importer: string
  /** The specifier as written, such as `./User.vibe` or `effect/Schema`. */
  readonly specifier: string
  /** The file the compiler resolved the specifier to. */
  readonly file: string
}

export interface Imports {
  /** Every file of the program except the compiler's bundled libraries. */
  readonly files: Array<string>
  /** Every import the program's files write, type-only imports included. */
  readonly imports: Array<Import>
  /** Diagnostics that stopped the compiler from reading the project; files and imports are then incomplete. */
  readonly errors: Array<Diagnostic>
}

/**
 * Where compiles are cached. VIBELANG_DISABLE_CACHE=1 turns the cache off
 * everywhere. Otherwise false turns it off, `directory` moves it, and without
 * an option it is VIBELANG_CACHE_DIR, else a private directory under the
 * system's temporary directory.
 */
export type CacheOption = false | { readonly directory: string }

export function findCompiler(root: string, compiler?: string): string
/**
 * The .vibe file whose module declaration compiles to `path`, as main.vibe's
 * `module text` compiles to main.vibe.text.js, or undefined.
 */
export function moduleDeclarationSource(path: string): string | undefined
/** exitIgnored holds `<category> <code>`, such as `error EK3889`, for each kind of diagnostic the build's exit status leaves out. */
export function parseOutput(output: string, root: string): { files: Array<string>; diagnostics: Array<Diagnostic>; exitIgnored: Set<string> }
export function parseExplainFiles(output: string, root: string): { files: Array<string>; roots: Array<string>; imports: Array<Import>; diagnostics: Array<Diagnostic> }
export function projectImports(options: { project: string; root?: string; compiler?: string }): Imports
export function formatDiagnostic(diagnostic: Diagnostic): string
export function projectBackend(options: {
  root: string
  compiler: string
  cache?: CacheOption
  /** Leave JSX in a `react-jsx` project's output for a tool that reads it; the tool then lowers it. `"react"`: only for a project on React's runtime. */
  preserveJsx?: boolean | "react"
  debug?: (text: string) => void
}): {
  compile(project: string): Promise<Result>
  /** Waits for compiles, terminating them after a bounded grace period, and closes their pipes. */
  close(): Promise<void>
}
export function compileProjectSync(options: {
  project: string
  root?: string
  compiler?: string
  cache?: CacheOption
  /** Leave JSX in a `react-jsx` project's output for a tool that reads it; the tool then lowers it. `"react"`: only for a project on React's runtime. */
  preserveJsx?: boolean | "react"
  debug?: (text: string) => void
}): Result
/**
 * Compiles a project as the loaders do and writes its loader record,
 * `<project dir>/.vibelang/js/.loader/<name>.json`, which a process with a
 * cold cache uses in place of the compile while every input holds. Returns
 * the record and its module count, or the errors of a project that does not
 * compile, which leaves no record.
 */
export function writeLoaderRecord(options: {
  project: string
  root?: string
  compiler?: string
}): { file: string; modules: number } | { errors: Diagnostic[] }
/**
 * Checks a project's loader record against the current tree as a cold loader
 * does: `{ modules }` when every input holds, else `{ miss }` naming the first
 * input that does not.
 */
export function checkLoaderRecord(options: {
  project: string
  root?: string
  compiler?: string
}): { modules: number } | { miss: string }
export function nearestProject(file: string): string | undefined
/** The nearest package.json directory, or the path's directory when none exists. */
export function packageRoot(path: string): string
/** Find a containing program after the initial config excludes a source. */
export function findProject(file: string, options: {
  project?: string
  tried?: string
  compiler?: string
  programs?: Map<string, Imports & { roots: Array<string>; composite?: boolean }>
}): { project: string | undefined; searched: string[] }

/**
 * The project that compiles `file` when `project` (in directory `root`) is asked
 * for: the nearest nested config, otherwise `project`. Other workspace packages
 * use their own nearest config. A missing module is resolved by findProject.
 */
export function workspaceProject(file: string, root: string, project: string): string
export function projects(options: {
  root: string
  project: string
  compiler: string
  cache?: CacheOption
  /** Leave JSX in a `react-jsx` project's output for a tool that reads it; the tool then lowers it. `"react"`: only for a project on React's runtime. */
  preserveJsx?: boolean | "react"
  debug?: (text: string) => void
}): {
  projectOf(file: string): string
  /** Closes every project backend. Further loads reject. */
  close(): Promise<void>
  invalidate(): void
  load(file: string): Promise<Loaded>
}
