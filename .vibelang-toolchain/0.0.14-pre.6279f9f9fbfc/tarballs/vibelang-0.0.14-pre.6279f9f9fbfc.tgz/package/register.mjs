import { inlineSourceMap } from "./inline-source-map.mjs"
import { rememberSourceMap } from "./source-map-frames.mjs"
import { loaderMiss, loaderScope } from "./loader-scope.mjs"
import { extensionlessImport } from "./relative-imports.mjs"
import { sourceOfEmitted } from "./emitted-js.mjs"
import { diagnosticsForFile } from "./diagnostics.mjs"
import { fileHasVibeDirective } from "./source.mjs"
// node --import vibelang/register: Node loads .vibe modules from source.
//
// A .vibe module keeps its source URL as its identity, so a program that also
// imports .ts files sees one copy of each module. Its JavaScript comes from one
// whole-project compile per tsconfig: emit is type-directed, so no module
// compiles alone. The project is the nearest tsconfig.json above the module, or
// VIBELANG_PROJECT for the modules in its directory; a module of another
// workspace package, such as a dependency linked to its source, compiles with
// its own package's tsconfig.json. A compile's result is cached on disk (vibelang/project), so
// a later process reuses it while the project's inputs are unchanged. A failed
// compile throws an Error with code ERR_VIBELANG_COMPILE and the diagnostics;
// a module the project does not include, ERR_VIBELANG_PROJECT. Source maps are
// turned on, so a stack frame names the .vibe line. A module declaration of a
// .vibe module is a module of its own, main.vibe.text.js beside main.vibe for
// module text (D403); its URL names that file, which is not on disk, and its
// JavaScript comes from the same compile.
// VIBELANG_REGISTER_DEBUG=1 reports each project's compile, with the time of
// each stage, or its cache hit, and at exit the time the hook took in all.
import { spawnSync } from "node:child_process"
import { existsSync, realpathSync, statSync } from "node:fs"
import * as Module from "node:module"
import { registerHooks } from "node:module"
import { dirname, resolve } from "node:path"
import { performance } from "node:perf_hooks"
import { fileURLToPath, pathToFileURL } from "node:url"
import { cacheDirectory } from "./cache.mjs"
import { compileProjectSync, findCompiler, findProject, formatDiagnostic, moduleDeclarationSource, nearestProject, packageRoot, workspaceProject } from "./project.mjs"

if (typeof registerHooks !== "function") {
  throw new Error(`vibelang/register needs module.registerHooks, in Node 22.15 or later; this is Node ${process.version}`)
}

// A .vibe module's frames name its .vibe path; without source maps they would
// carry the emitted JavaScript's line numbers. Node 22.14+ (every Node with
// registerHooks) has setSourceMapsSupport.
Module.setSourceMapsSupport?.(true)

const results = new Map()
const debug = process.env.VIBELANG_REGISTER_DEBUG
  ? (text) => process.stderr.write(`vibelang/register: ${text}\n`)
  : undefined

// What the hook cost this process, for the debug report at exit: the projects
// it compiled or read from the cache, the modules it loaded, and the
// relative imports it resolved to sources.
const spent = { projects: 0, compile: 0, modules: 0, load: 0, imports: 0, resolve: 0 }
const since = (started) => performance.now() - started
if (debug) {
  process.on("exit", () => {
    const ms = (value) => `${Math.round(value)}ms`
    const count = (n, one, many) => `${n} ${n === 1 ? one : many}`
    debug(`${count(spent.projects, "project", "projects")} compiled or read from the cache in ${ms(spent.compile)}, ` +
      `${count(spent.modules, "module", "modules")} loaded in ${ms(spent.load)}, ` +
      `${count(spent.imports, "import resolved to its source", "imports resolved to their sources")} in ${ms(spent.resolve)}`)
  })
}

// Modules their first project left out, each with the project findProject named.
const owners = new Map()
const programs = new Map()

function projectOf(file) {
  if (owners.has(file)) return owners.get(file)
  if (process.env.VIBELANG_PROJECT) {
    const named = resolve(process.env.VIBELANG_PROJECT)
    return workspaceProject(file, dirname(named), named)
  }
  const project = nearestProject(file)
  if (project === undefined) throw new Error(`vibelang/register: no tsconfig.json above ${file}`)
  return project
}

// An Error with a code, as Node's own module errors have.
const failure = (code, message) => Object.assign(new Error(message), { code })

// A file saved after a compile started may be missing from its output.
function changedSince(file, time) {
  const stat = statSync(file, { throwIfNoEntry: false })
  return stat !== undefined && Math.max(stat.mtimeMs, stat.ctimeMs) > time
}

// The projects this process found uncached.
const coldProjects = new Set()

// One compile can be an edited project; a second project says the cache is cold, and
// the projects still to come are compiled at once, in a child because this
// hook cannot wait for anything else. The cache is what it leaves behind: if
// it fails, each project compiles here as it would have.
function prefill(project) {
  if (process.env.VIBELANG_PROJECT || cacheDirectory() === undefined) return
  const roots = [dirname(project), ...(process.argv[1] && existsSync(process.argv[1]) ? [packageRoot(realpathSync(process.argv[1]))] : [])]
  const { NODE_OPTIONS: _, ...env } = process.env
  spawnSync(process.execPath, [fileURLToPath(new URL("./register-prefill.mjs", import.meta.url)), ...roots], { env, stdio: ["ignore", "ignore", "inherit"], timeout: 120_000 })
}

// A long-running process compiles a project again when a module it imports
// is newer than the compile, or was not there yet: a watcher's re-import of
// an edited file, or a module written after the program started.
function emitted(file) {
  const project = projectOf(file)
  let compiled = results.get(project)
  // A module declaration's output is as new as its .vibe file.
  if (compiled !== undefined && changedSince(moduleDeclarationSource(file) ?? file, compiled.started)) compiled = undefined
  if (compiled !== undefined && !compiled.result.outputs.has(file) && !compiled.missing.has(file)) {
    compiled = undefined
  }
  if (compiled === undefined) {
    const started = Date.now()
    const clock = performance.now()
    const before = coldProjects.size
    compiled = { started, result: compileProjectSync({ project, debug, [loaderScope]: true, [loaderMiss]: () => coldProjects.add(project) }), missing: new Set() }
    results.set(project, compiled)
    spent.projects++
    spent.compile += since(clock)
    if (before === 1 && coldProjects.size === 2) prefill(project)
  }
  const { result } = compiled
  if (!result.outputs.has(file) && !owners.has(file)) {
    const other = findProject(file, { tried: project, compiler: findCompiler(dirname(project)), programs }).project
    if (other !== undefined) {
      owners.set(file, other)
      return emitted(file)
    }
  }
  const errors = diagnosticsForFile(result.errors, file, result.files)
  if (errors.length) {
    throw failure("ERR_VIBELANG_COMPILE", `vibelang: ${project} did not compile\n${errors.map(formatDiagnostic).join("\n")}`)
  }
  const output = result.outputs.get(file)
  if (output === undefined) {
    compiled.missing.add(file)
    if (result.files.some((source) => source === file || realpathSync(source) === file)) {
      throw failure("ERR_VIBELANG_OUTPUT", `vibelang/register: ${project} includes ${file}, but no loader output is available; dependencies in node_modules must publish compiled JavaScript or compile with their own workspace project`)
    }
    throw failure("ERR_VIBELANG_PROJECT", `vibelang/register: ${project} does not include ${file}; set VIBELANG_PROJECT to a tsconfig that does`)
  }
  return output
}

// vibelang rewrites a .vibe module's relative imports to the emitted .js names.
// From source, those names are the .vibe or TypeScript files beside it.
const sources = { ".js": [".vibe", ".ts", ".tsx"], ".mjs": [".mts"], ".cjs": [".cts"] }
const clean = (url) => url.replace(/[?#].*$/, "")

// A module declaration's output that is not on disk: the compile serves it.
function moduleOutput(url) {
  if (!url.startsWith("file:")) return undefined
  const path = fileURLToPath(clean(url))
  const source = moduleDeclarationSource(path)
  return source !== undefined && !existsSync(path) && existsSync(source) ? path : undefined
}

// A module vibelang compiles: a .vibe module, or a .ts module with the directive.
const compiledSource = (url) => url.startsWith("file:") && (clean(url).endsWith(".vibe") || fileHasVibeDirective(fileURLToPath(clean(url))))

// A module whose imports vibelang rewrote: a compiled source or a module declaration's.
const compiled = (url) => compiledSource(url) || moduleOutput(url) !== undefined

// A migrated package's emitted JavaScript, which its `default` export names
// for consumers without a loader, runs here from its .vibe source.
function toSource(result, context, nextResolve) {
  if (!result?.url?.startsWith("file:")) return result
  const source = sourceOfEmitted(fileURLToPath(clean(result.url)))
  if (source === undefined) return result
  try {
    return nextResolve(pathToFileURL(source).href, context)
  } catch (error) {
    // Node's CommonJS resolver accepts filesystem paths, not file: URLs.
    // Keep ESM's URL spelling (including encoded # and %) and preserve all
    // other resolver failures rather than retrying them as filesystem paths.
    if (error?.code !== "MODULE_NOT_FOUND") throw error
    return nextResolve(source, context)
  }
}

// A later JavaScript transformer must delegate native source to this load hook.
// Node permits a custom resolve-format hint; load supplies the final JS format.
// This also covers virtual module-declaration outputs, which are not on disk.
const nativeFormat = result => compiled(result.url) ? { ...result, format: "vibelang" } : result

registerHooks({
  resolve(specifier, context, nextResolve) {
    // Migrated packages expose source before their default JavaScript is built.
    // Preserve Node's import/require and user conditions when selecting it.
    if (!context.conditions.includes("vibelang-source")) {
      context = { ...context, conditions: [...context.conditions, "vibelang-source"] }
    }
    const started = performance.now()
    try {
      return nativeFormat(toSource(nextResolve(specifier, context), context, nextResolve))
    } catch (error) {
      const parent = context.parentURL
      const missing = ["ERR_MODULE_NOT_FOUND", "ERR_UNSUPPORTED_DIR_IMPORT", "MODULE_NOT_FOUND"].includes(error?.code)
      if (!missing || !/^\.\.?(?:\/|$)/.test(specifier) || !parent?.startsWith("file:")) throw error
      const target = new URL(specifier, parent)
      const resolved = (result) => {
        spent.imports++
        spent.resolve += since(started)
        return nativeFormat(result)
      }
      // TypeScript resolves an extensionless import, ./archive, to
      // archive.vibe after archive.ts and archive.tsx; Node's own resolution
      // knows no .vibe file. From a compiled module, the same lookup also serves
      // TypeScript and JavaScript siblings; declarations have no runtime source.
      const source = extensionlessImport(dirname(fileURLToPath(parent)), clean(specifier))
      const nativeSource = source && /\.(?:tsx?|jsx?)$/.test(source) && !source.endsWith(".d.ts")
      if (source?.endsWith(".vibe") || nativeSource && compiled(parent)) {
        return resolved(nextResolve(pathToFileURL(source).href + target.search + target.hash, context))
      }
      if (error.code !== "ERR_MODULE_NOT_FOUND" || !compiled(parent)) throw error
      if (moduleOutput(target.href) !== undefined) return resolved({ url: target.href, format: "module", shortCircuit: true })
      const path = fileURLToPath(clean(target.href))
      const extension = Object.keys(sources).find((name) => path.endsWith(name))
      for (const replacement of extension === undefined ? [] : sources[extension]) {
        const candidate = path.slice(0, -extension.length) + replacement
        if (existsSync(candidate)) return resolved(nextResolve(pathToFileURL(candidate).href + target.search + target.hash, context))
      }
      throw error
    }
  },
  load(url, context, nextLoad) {
    const path = moduleOutput(url) ?? (compiledSource(url) ? fileURLToPath(clean(url)) : undefined)
    if (path === undefined) return nextLoad(url, context)
    const started = performance.now()
    const compile = spent.compile
    const { code, map } = emitted(path)
    // Node resolves a source against the module URL: a path with # or %, or a
    // Windows drive, needs a file URL.
    const sources = map.sources.map((source) => pathToFileURL(source).href)
    const payload = { ...map, sources }
    rememberSourceMap(url, payload)
    spent.modules++
    spent.load += since(started) - (spent.compile - compile)
    return {
      format: "module",
      source: `${code}\n${inlineSourceMap(payload)}\n`,
      shortCircuit: true
    }
  }
})
